<?php 
session_start();
//echo $_SESSION["dlpd"];
if ($_SESSION["dlpd"]=="no"){
		echo "<script>location.href='../login.php';</script>";
		 exit();
}

?>
<!doctype html>
<html>
<head>
    <meta charset="UTF-8"/>
    <title>我的网站系统后台管理模板</title>
    <link rel="stylesheet" type="text/css" href="css/common.css"/>
    <link rel="stylesheet" type="text/css" href="css/main.css"/>
</head>
<body>
<div class="topbar-wrap white">
    <div class="topbar-inner clearfix">
        <div class="topbar-logo-wrap clearfix">
            <h1 class="topbar-logo none"><a href="index.php" class="navbar-brand">我的网站后台管理</a></h1>
            <ul class="navbar-list clearfix">
                <li><a class="on" href="admin_index.php">首页</a></li>
                <li><a href="admin_index.php" target="_blank">网站首页</a></li>
            </ul>
        </div>
        <div class="top-info-wrap">
            <ul class="top-info-list clearfix">
                <li><a href="#">管理员</a></li>
                <li><a href="#">修改密码</a></li>
                <li><a href="exit.php">退出</a></li>
            </ul>
        </div>
    </div>
</div>
<div class="container clearfix">
    <div class="sidebar-wrap">
        <div class="sidebar-title">
            <h1>菜单</h1>
        </div>
        <div class="sidebar-content">
            <ul class="sidebar-list">
                <li>
                    <a href="#"><i class="icon-font">&#xe003;</i>常用操作</a>
                    <ul class="sub-menu">
                        <li><a href="design_news.php"><i class="icon-font">&#xe008;</i>新闻管理</a></li>
                        <li><a href="design_user.php"><i class="icon-font">&#xe005;</i>用户管理</a></li>
                        <li><a href="design_record.php"><i class="icon-font">&#xe006;</i>记录管理</a></li>
                        <li><a href="design_pic.php"><i class="icon-font">&#xe004;</i>图片管理</a></li>
                        <li><a href="design_link.php"><i class="icon-font">&#xe012;</i>友情链接</a></li>
                        <li><a href="design.php"><i class="icon-font">&#xe052;</i>评论管理</a></li>
                        <li><a href="design2.php"><i class="icon-font">&#xe033;</i>广告管理1</a></li>
                        <li><a href="design.php"><i class="icon-font">&#xe030;</i>广告管理2</a></li>
                        <li><a href="design.php"><i class="icon-font">&#xe023;</i>广告管理3</a></li>
                        <li><a href="design.php"><i class="icon-font">&#xe013;</i>广告管理4</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#"><i class="icon-font">&#xe018;</i>系统管理</a>
                    <ul class="sub-menu">
                        <li><a href="system.php"><i class="icon-font">&#xe017;</i>系统设置</a></li>
                        <li><a href="system.php"><i class="icon-font">&#xe037;</i>清理缓存</a></li>
                        <li><a href="system.php"><i class="icon-font">&#xe046;</i>数据备份</a></li>
                        <li><a href="system.php"><i class="icon-font">&#xe045;</i>数据还原</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
    <!--/sidebar-->
    <div class="main-wrap">
        <div class="crumb-wrap">
            <div class="crumb-list"><i class="icon-font">&#xe06b;</i><span>欢迎使用『我的网站』博客程序，建博的首选工具。</span></div>
        </div>
        <div class="result-wrap">
            <div class="result-title">
                <h1>快捷操作</h1>
            </div>
            <div class="result-content">
                <div class="short-wrap">
                    <a href="insert_news.php"><i class="icon-font">&#xe001;</i>新增新闻</a>
                    <a href="insert.php"><i class="icon-font">&#xe005;</i>新增博文</a>
                    <a href="insert.php"><i class="icon-font">&#xe048;</i>新增作品分类</a>
                    <a href="insert.php"><i class="icon-font">&#xe041;</i>新增博客分类</a>
                    <a href="#"><i class="icon-font">&#xe01e;</i>作品评论</a>
                </div>
            </div>
        </div>
        <div class="result-wrap">
            <div class="result-title">
                <h1>系统基本信息</h1>
            </div>
            <div class="result-content">
                <ul class="sys-info-list">
                    <li>
                        <label class="res-lab">操作系统</label><span class="res-info">WINNT</span>
                    </li>
                    <li>
                        <label class="res-lab">运行环境</label><span class="res-info">Apache/2.2.21 (Win64) PHP/5.3.10</span>
                    </li>
                    <li>
                        <label class="res-lab">PHP运行方式</label><span class="res-info">apache2handler</span>
                    </li>
                    <li>
                        <label class="res-lab">静静设计-版本</label><span class="res-info">v-0.1</span>
                    </li>
                    <li>
                        <label class="res-lab">上传附件限制</label><span class="res-info">2M</span>
                    </li>
                    <li>
                        <label class="res-lab">北京时间</label><span class="res-info">2014年3月18日 21:08:24</span>
                    </li>
                    <li>
                        <label class="res-lab">服务器域名/IP</label><span class="res-info">localhost [ 127.0.0.1 ]</span>
                    </li>
                    <li>
                        <label class="res-lab">Host</label><span class="res-info">127.0.0.1</span>
                    </li>
                </ul>
            </div>
        </div>
        <div class="result-wrap">
            <div class="result-title">
                <h1>使用帮助</h1>
            </div>
            <div class="result-content">
                <ul class="sys-info-list">
                    <li>
                        <label class="res-lab">更多模板：</label><span class="res-info"><a href="http://www.codejie.net/" target="_blank">源码街-免费源码下载</a></span>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <!--/main-->
</div>
</body>
</html>